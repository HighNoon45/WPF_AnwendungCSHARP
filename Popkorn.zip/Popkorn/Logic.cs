﻿using Prism.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Popkorn
{
    public class Logic : Good
    {
        private ObservableCollection<Good> _goods;
        public ObservableCollection<Good> Goods
        {
            get { return _goods; }
            set
            {
                _goods = value;
                RaisePropertyChanged("Goods");
            }
        }


        public Logic()
        {
            //hard coded data for testing
            Goods = new ObservableCollection<Good>();
            List<string> names = new List<string>() { "Tammy", "Doug", "Jeff", "Greg", "Kris", "Mike", "Joey", "Leslie", "Emily", "Tom" };
            List<int> ages = new List<int>() { 32, 24, 42, 57, 17, 73, 12, 8, 29, 31 };

            for (int i = 0; i < 10; i++)
            {
                Good item = new Good();
                item.Name = names[i];
                item.Price = ages[i];
                Goods.Add(item);
            }
        }
    }
}
